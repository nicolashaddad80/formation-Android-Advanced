package com.training.renault.mobzoo;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;


public class AnimalListFragment extends Fragment {

    private AnimalViewModel mAnimalViewModel;
    private TableLayout mAnimalTable;

    public AnimalListFragment() {
       super(R.layout.fragment_animal_list);
    }



    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mAnimalViewModel = new ViewModelProvider(requireActivity()).get(AnimalViewModel.class);

        Log.i("mAnimalViewModel", mAnimalViewModel.hashCode()+"");
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mAnimalTable = view.findViewById(R.id.animalTable);

        addAnimalRow(mAnimalViewModel.getName(), mAnimalViewModel.getWeight(), mAnimalViewModel.isCarnivore());
    }

    private void addAnimalRow(String name, int weight, boolean carnivore) {

        TableRow row = new TableRow(requireContext());
        TextView textName = new TextView(requireContext());
        textName.setText(name);
        row.addView(textName);

        TextView textWeight = new TextView(requireContext());
        textWeight.setText(weight+"");
        row.addView(textWeight);

        TextView textCarnivore = new TextView(requireContext());
        textCarnivore.setText(carnivore?"X":"");
        row.addView(textCarnivore);

        mAnimalTable.addView(row);

    }
}