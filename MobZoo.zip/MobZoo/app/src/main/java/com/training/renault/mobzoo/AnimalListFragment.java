package com.training.renault.mobzoo;

import android.os.Bundle;
import android.util.Log;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;


public class AnimalListFragment extends Fragment {

    private AnimalViewModel mAnimalViewModel;

    public AnimalListFragment() {
       super(R.layout.fragment_animal_creation);
    }



    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mAnimalViewModel = new ViewModelProvider(requireActivity()).get(AnimalViewModel.class);
        Log.i("mAnimalViewModel", mAnimalViewModel.hashCode()+"");
    }


}