package com.training.renault.mobzoo;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;


public class AnimalCreationFragment extends Fragment {

    private AnimalViewModel mAnimalViewModel;

    public AnimalCreationFragment() {
       super(R.layout.fragment_animal_creation);
    }



    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mAnimalViewModel = new ViewModelProvider(requireActivity()).get(AnimalViewModel.class);
        Log.i("mAnimalViewModel", mAnimalViewModel.hashCode()+"");
    }


}