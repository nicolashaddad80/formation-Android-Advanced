package com.training.renault.mobzoo;

import androidx.lifecycle.ViewModel;

public class AnimalViewModel extends ViewModel {

    private String name;
    private int weight;
    private boolean carnivore;


    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    public boolean isCarnivore() {
        return carnivore;
    }

    public void setCarnivore(boolean carnivore) {
        this.carnivore = carnivore;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
