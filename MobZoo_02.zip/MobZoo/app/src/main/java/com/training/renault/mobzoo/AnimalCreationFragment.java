package com.training.renault.mobzoo;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.SwitchCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


public class AnimalCreationFragment extends Fragment {

    private AnimalViewModel mAnimalViewModel;
    private Button mAddBtn;
    private EditText mEditName;
    private EditText mEditWeight;
    private SwitchCompat mSwitchCarnivore;

    public AnimalCreationFragment() {
        super(R.layout.fragment_animal_creation);
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mAnimalViewModel = new ViewModelProvider(requireActivity()).get(AnimalViewModel.class);

        Log.i("mAnimalViewModel", mAnimalViewModel.hashCode() + "");
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mAddBtn = view.findViewById(R.id.addBtn);
        mEditName = view.findViewById(R.id.editAnimalName);
        mEditWeight = view.findViewById(R.id.editAnimalWeight);
        mSwitchCarnivore = view.findViewById(R.id.switchCarnivore);

        mAddBtn.setOnClickListener(v -> {
            mAnimalViewModel.setName(mEditName.getText().toString());
            mAnimalViewModel.setWeight(Integer.parseInt(mEditWeight.getText().toString()));
            mAnimalViewModel.setCarnivore(mSwitchCarnivore.isChecked());

        });

    }
}